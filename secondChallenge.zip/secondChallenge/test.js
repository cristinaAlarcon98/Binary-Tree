var assert = require('assert');
var secondChallengeApp = require("./secondChallengeApp");

describe('Second Challenge Test', function () {
    it('should return true when the given values are natural numbers', function () {
     assert.equal(secondChallengeApp.isNatural(['5','10','15']), true);
    });

    it('should return false when at least one given value is not a natural number', function () {
        assert.equal(secondChallengeApp.isNatural(['0','1.3','2']), false);
    });
    
    it('should return false when at least one given value is not a natural number', function () {
        assert.equal(secondChallengeApp.isNatural(['0','1.3','S']), false);
    });

    it('should return the least common multiple of the given parameters', function () {
        assert.equal(secondChallengeApp.findLCM(['20','15','10']), 60);
    });

    it('should return the least common multiple of the given parameters', function () {
        assert.equal(secondChallengeApp.findLCM(['24','36']), 72);
    });
    it('should return the least common multiple of the given parameters', function () {
        assert.equal(secondChallengeApp.findLCM(['3','6','9']), 18);
    });

    
    

 
});