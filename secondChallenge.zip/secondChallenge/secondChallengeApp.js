

const express = require('express')
const app = express()
const port = 8080

app.get('/lcm', (req, res) => {

    let params=req.query.queryParams

    
    if (isNatural(params)==false){
        
        res.status(422).send('Only natural numbers may be used to calculate a LCM')

    }else if (params<2){

        res.status(422).send('Only at least two natural numbers must be provided to compute the LCM')

    }else{

    res.status(200).send(' The LCM of ' +params +' is '+ findLCM(params))

    }
})

app.listen(port, () => {
  console.log(`Listening on port ${port}`)
})



/**
 * Calculates the Least common multiple (LCM) of diferent numbers contained in an array
 * @param {Array} paramsArrayStr - The array with numbers in String format
 * @return {number} - The lcm calculated
 */
function findLCM(paramsArrayStr){

    // Parses each input element to int 
    let paramsArrayInt=parseArrayToInt(paramsArrayStr)
    
    // Initialize result
    let lcm = paramsArrayInt[0];
 
    // lcm contains LCM of paramsArrayInt[0], ..paramsArrayInt[i] after each iteration
    for (let i = 1; i < paramsArrayInt.length; i++){
        lcm = (((paramsArrayInt[i] * lcm)) /
                (gcd(paramsArrayInt[i], lcm)));
    }
 
    return lcm;
}


/**
 * Calculates the greatest common divisor of two numbers using the Euclidean Algorithm
 * @param {number} a 
 * @param {number} b 
 * @return {number} - The greatest common divisor of given numbers
 */
function gcd(a, b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}


/**
 * Checks if all input numbers are natural
 * @param {number} params 
 * @return {boolean} 
 */
function isNatural(arrValues) {
    
    for (let i = 0; i < arrValues.length; i++){
        n=arrValues[i]
        
        if ((n < 0.0) || (Math.floor(n) != n) || n == Infinity){   
            return false
        }  
    }

    return true    
}


/**
 * Parses to Int an array of string values 
 * @param {Array} arrValues 
 * @return {boolean} 
 */
function parseArrayToInt(valuesStr){
    
    let valuesInt=[]
    for (let i=0; i<valuesStr.length; i++){
        valuesInt.push(parseInt(valuesStr[i]))
    }
    return valuesInt
}
   

module.exports = { isNatural, findLCM };